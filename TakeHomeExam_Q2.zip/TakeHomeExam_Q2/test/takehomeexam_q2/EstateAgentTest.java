/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package takehomeexam_q2;
//ST10261605

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Sami
 */
public class EstateAgentTest {
    
    public EstateAgentTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void CalculateCommission_CalculatedSuccessfully() {
        // calculates commission, if true, test passes
        System.out.println("Calculate Commission Successful");
        double propertyPrice = 800000;
        double agentCommission = 10.00 ;
        EstateAgent instance = new EstateAgent();
        double expResult = 80000.00;
        double result = instance.CalculateCommission(propertyPrice, agentCommission);
        assertEquals(expResult, result, 80000.00);

    }
    
    @Test
    public void CalculateCommission_CalculatedUnsuccessfully() {
        System.out.println("Calculate Commission Unsuccessful");
        double propertyPrice = 800000;
        double agentCommission = 10.00 ;
        EstateAgent instance = new EstateAgent();
        double expResult = 20.00;
        double result = instance.CalculateCommission(propertyPrice, agentCommission);
        assertEquals(expResult, result, 80000.00);
    }

    @Test
    public void ValidateData() {
        //validates data
        System.out.println("ValidateData");
        Data dataToValidate = new Data("Cape Town", "Joe Bloggs", 800000.00, 10.00);
        EstateAgent instance = new EstateAgent();
        boolean expResult = true;
        boolean result = instance.ValidateData(dataToValidate);
        assertEquals(expResult, result);
    }
    
}

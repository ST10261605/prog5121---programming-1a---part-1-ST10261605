/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package takehomeexam_q2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Sami
 */
public class DataTest {
    
    public DataTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of setLocation method, of class Data.
     */
    @Test
    public void testSetLocation() {
        System.out.println("setLocation");
        String location = "";
        Data instance = null;
        instance.setLocation(location);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setName method, of class Data.
     */
    @Test
    public void testSetName() {
        System.out.println("setName");
        String name = "";
        Data instance = null;
        instance.setName(name);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setPropertyPrice method, of class Data.
     */
    @Test
    public void testSetPropertyPrice() {
        System.out.println("setPropertyPrice");
        double propertyPrice = 0.0;
        Data instance = null;
        instance.setPropertyPrice(propertyPrice);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setAgentCommission method, of class Data.
     */
    @Test
    public void testSetAgentCommission() {
        System.out.println("setAgentCommission");
        double agentCommission = 0.0;
        Data instance = null;
        instance.setAgentCommission(agentCommission);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLocation method, of class Data.
     */
    @Test
    public void testGetLocation() {
        System.out.println("getLocation");
        Data instance = null;
        String expResult = "";
        String result = instance.getLocation();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getName method, of class Data.
     */
    @Test
    public void testGetName() {
        System.out.println("getName");
        Data instance = null;
        String expResult = "";
        String result = instance.getName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPropertyPrice method, of class Data.
     */
    @Test
    public void testGetPropertyPrice() {
        System.out.println("getPropertyPrice");
        Data instance = null;
        double expResult = 0.0;
        double result = instance.getPropertyPrice();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getAgentCommission method, of class Data.
     */
    @Test
    public void testGetAgentCommission() {
        System.out.println("getAgentCommission");
        Data instance = null;
        double expResult = 0.0;
        double result = instance.getAgentCommission();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}

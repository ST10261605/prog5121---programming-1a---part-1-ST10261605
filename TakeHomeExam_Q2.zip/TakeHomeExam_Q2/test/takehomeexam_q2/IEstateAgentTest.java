/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package takehomeexam_q2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Sami
 */
public class IEstateAgentTest {
    
    public IEstateAgentTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of CalculateCommission method, of class IEstateAgent.
     */
    @Test
    public void testCalculateCommission() {
        System.out.println("CalculateCommission");
        double propertyPrice = 0.0;
        double agentCommission = 0.0;
        IEstateAgent instance = new IEstateAgentImpl();
        double expResult = 0.0;
        double result = instance.CalculateCommission(propertyPrice, agentCommission);
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of ValidateData method, of class IEstateAgent.
     */
    @Test
    public void testValidateData() {
        System.out.println("ValidateData");
        Data dataToValidate = null;
        IEstateAgent instance = new IEstateAgentImpl();
        boolean expResult = false;
        boolean result = instance.ValidateData(dataToValidate);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    public class IEstateAgentImpl implements IEstateAgent {

        public double CalculateCommission(double propertyPrice, double agentCommission) {
            return 0.0;
        }

        public boolean ValidateData(Data dataToValidate) {
            return false;
        }
    }
    
}

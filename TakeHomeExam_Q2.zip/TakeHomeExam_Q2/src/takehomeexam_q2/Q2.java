/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package takehomeexam_q2;
//ST10261605

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

//our class needs to implement ActionListener for the menuBar to function
public class Q2 extends javax.swing.JFrame implements ActionListener {
    
    //declaring array of locations to populate combo box with
    String [] locations = {"Cape Town", "Durban", "Pretoria"};
    
    //declaring global variables 
    String agentLocation, agentName;
    double propertyPrice, commissionPerc;
    
    //instantating EstateAgent object
    EstateAgent estateAgent;
    
    //declaring JMenuBar, JMenu and JMenuItems
    JMenuBar menuBar;
    JMenu fileMenu;
    JMenu toolsMenu;
    JMenuItem exitItem;
    JMenuItem processItem; 
    JMenuItem clearItem; 
    JMenuItem saveItem; 

    public Q2() {
        initComponents();
        
        //instantiating new EstateAgent object
        estateAgent = new EstateAgent();
        //populating location in the combo box "Locations"
        populateLocations();
        
        menuBar = new JMenuBar(); //creating a menu bar
          
        this.setJMenuBar(menuBar); //setting a menu bar in this form
          
        fileMenu = new JMenu("File"); //creating the options for the menu bar
        toolsMenu = new JMenu("Tools"); 
        
        menuBar.add(fileMenu); //adding them to the frame
        menuBar.add(toolsMenu);
         
        exitItem = new JMenuItem("Exit"); //adding items for the options 
        fileMenu.add(exitItem); //adding exit option to File menu
        
        processItem = new JMenuItem("Process Report");
        toolsMenu.add(processItem); //adding process option to tools menu
        
        clearItem = new JMenuItem("Clear");
        toolsMenu.add(clearItem); //adding clear option to tools menu
        
        saveItem = new JMenuItem("Save");
        toolsMenu.add(saveItem); //adding save option to tools menu
        
        //adding actions so that when clicked, the options will function as intended
        exitItem.addActionListener(this); 
        processItem.addActionListener(this);
        saveItem.addActionListener(this);
        clearItem.addActionListener(this);      
    }
    
    //method to allow the menuItems to function
    @Override
        public void actionPerformed (ActionEvent e) {
            if (e.getSource() == exitItem) { //if the item "exit" in the menuBar is clicked
                System.exit(0); //exit the application
            }
            
        if (e.getSource() == processItem) { //if the item "process report" in the menuBar is clicked
               agentLocation = (String) cmbLocation.getSelectedItem(); //get location
               agentName = txtName.getText(); //get name 
               propertyPrice = Double.parseDouble(txtPrice.getText()); // Convert string to double
               commissionPerc = Double.parseDouble(txtCommission.getText()); // Convert string to double
                       
              //use validate data method from Data class in EstateAgent to ensure data is valid/entered correctly
              Data dataToValidate = new Data(agentLocation, agentName, propertyPrice, commissionPerc);
              boolean isValid = estateAgent.ValidateData(dataToValidate);

              if (isValid) {
                // If data is valid, proceed with processing
                //printing out details to text area
                txtAreaReport.append("AGENT LOCATION: " + agentLocation + "\n");
                txtAreaReport.append("AGENT NAME: " + agentName + "\n");
                
                //using "String.valueOf" to convert double to String so it can be printed
                txtAreaReport.append("PROPERTY PRICE: R" + String.valueOf(propertyPrice) + "\n"); 
                txtAreaReport.append("COMMISSION PERCENTAGE: " + String.valueOf(commissionPerc) + "%" + "\n");
                
                //using calculateCommission method from EstateAgent class
                txtAreaReport.append("CALCULATED COMMISSION: R " + estateAgent.CalculateCommission(propertyPrice, commissionPerc)); 
              } else {
                // If data is not valid, display an error message 
                txtAreaReport.append("Invalid data. Please check your input.\n");
            }     
            }
        
        if (e.getSource() == saveItem) { //if the item "save" in the menuBar is clicked
            writeToFile(); //call writeToFile() method
        }
        
        if (e.getSource() == clearItem) { //if the item "clear" in the menuBar is clicked
            //set all values to default values
            cmbLocation.setSelectedIndex(0); 
            txtName.setText("");
            txtPrice.setText("");
            txtCommission.setText("");
            txtAreaReport.setText("");
        }
        }
    
    //populating locations combo box
    private void populateLocations() {
         for (int i = 0; i < locations.length; i++) {
            cmbLocation.addItem(locations[i]);
        }
    }
    
    public void writeToFile() {
        
        agentLocation = (String) cmbLocation.getSelectedItem(); //getting location
        agentName = txtName.getText(); //getting name 
        propertyPrice = Double.parseDouble(txtPrice.getText()); // Convert string to double
        commissionPerc = Double.parseDouble(txtCommission.getText()); // Convert string to double
        
        //creating new fileWriter
        FileWriter writer ;
        try {
            File checkIfFileExists = new File("report.txt"); //checking if textfile "report" exists
            writer = new FileWriter("report.txt"); //appending it
           
            //writing estate agent report to the textfile
            writer.append("ESTATE AGENT REPORT" + "\n");
            writer.append("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" + "\n");
            writer.append("AGENT LOCATION: " + agentLocation + "\n");
            writer.append("AGENT NAME: " + agentName + "\n");
            writer.append("PROPERTY PRICE: R" + String.valueOf(propertyPrice) + "\n");
            writer.append("COMMISSION PERCENTAGE: " + String.valueOf(commissionPerc) + "%" + "\n");
            writer.append("CALCULATED COMMISSION: R " + estateAgent.CalculateCommission(propertyPrice, commissionPerc) + "\n");
            writer.append("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            writer.close();
            //confirm message to let user know agent report has been printed to textfile
            JOptionPane.showMessageDialog(null, "Estate Agent Report saved successfully!");
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage()); 
            //this prints out "An error has occured"
        }      
    }
    
  

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblLocation = new javax.swing.JLabel();
        lblName = new javax.swing.JLabel();
        lblPrice = new javax.swing.JLabel();
        lblCommission = new javax.swing.JLabel();
        lblReport = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        txtPrice = new javax.swing.JTextField();
        txtCommission = new javax.swing.JTextField();
        cmbLocation = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtAreaReport = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 153, 153));

        lblLocation.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        lblLocation.setText("AGENT LOCATION:");

        lblName.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        lblName.setText("ESTATE AGENT NAME:");

        lblPrice.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        lblPrice.setText("PROPERTY PRICE:");

        lblCommission.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        lblCommission.setText("COMMISSION PERCENTAGE:");

        lblReport.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        lblReport.setText("ESTATE AGENT REPORT:");

        txtName.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        txtName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNameActionPerformed(evt);
            }
        });

        txtPrice.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N

        txtCommission.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        txtCommission.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCommissionActionPerformed(evt);
            }
        });

        cmbLocation.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        cmbLocation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbLocationActionPerformed(evt);
            }
        });

        txtAreaReport.setColumns(20);
        txtAreaReport.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        txtAreaReport.setRows(5);
        jScrollPane2.setViewportView(txtAreaReport);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblCommission))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblPrice))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblName))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblLocation)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 116, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtCommission)
                    .addComponent(txtPrice)
                    .addComponent(txtName)
                    .addComponent(cmbLocation, 0, 195, Short.MAX_VALUE))
                .addGap(30, 30, 30))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblReport)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblLocation)
                    .addComponent(cmbLocation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblName, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCommission, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCommission, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addComponent(lblReport, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 222, Short.MAX_VALUE)
                .addGap(24, 24, 24))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtCommissionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCommissionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCommissionActionPerformed

    private void txtNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNameActionPerformed

    private void cmbLocationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbLocationActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbLocationActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Q2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Q2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Q2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Q2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Q2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cmbLocation;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblCommission;
    private javax.swing.JLabel lblLocation;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblPrice;
    private javax.swing.JLabel lblReport;
    private javax.swing.JTextArea txtAreaReport;
    private javax.swing.JTextField txtCommission;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtPrice;
    // End of variables declaration//GEN-END:variables
}

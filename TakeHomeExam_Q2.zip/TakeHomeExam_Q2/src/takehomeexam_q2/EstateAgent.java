/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package takehomeexam_q2;
//ST10261605

 class Data {
    //declerations
    private String location;
    private String name;
    private double propertyPrice;
    private double agentCommission;

    //setters
    public void setLocation(String location) {
        this.location = location;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPropertyPrice(double propertyPrice) {
        this.propertyPrice = propertyPrice;
    }

    public void setAgentCommission(double agentCommission) {
        this.agentCommission = agentCommission;
    }

    //constructor
    public Data(String location, String name, double propertyPrice, double agentCommission) {
        this.location = location;
        this.name = name;
        this.propertyPrice = propertyPrice;
        this.agentCommission = agentCommission;
    }

    //getters
    public String getLocation() {
        return location;
    }

    public String getName() {
        return name;
    }

    public double getPropertyPrice() {
        return propertyPrice;
    }

    public double getAgentCommission() {
        return agentCommission;
    }
}

public class EstateAgent implements IEstateAgent {

    @Override
    public double CalculateCommission(double propertyPrice, double agentCommission) {
        //calculating commission amount and returning it
        return propertyPrice * (agentCommission / 100.0); 
    }

    @Override
    public boolean ValidateData(Data dataToValidate) {
        //returns whether data is valid or not
        return isLocationValid(dataToValidate.getLocation())
                && isNameValid(dataToValidate.getName())
                && isPropertyPriceValid(dataToValidate.getPropertyPrice())
                && isCommissionValid(dataToValidate.getAgentCommission());
    }

    // Helper methods for data validation
    private boolean isLocationValid(String location) {
        return !location.isEmpty();
    }

    private boolean isNameValid(String name) {
        return !name.isEmpty();
    }

    private boolean isPropertyPriceValid(double propertyPrice) {
        return propertyPrice > 0;
    }

    private boolean isCommissionValid(double agentCommission) {
        return agentCommission > 0;
    }
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package takehomeexam_q2;
//ST10261605

public  interface IEstateAgent {
    double CalculateCommission(double propertyPrice, double agentCommission);
    boolean ValidateData(Data dataToValidate);
}

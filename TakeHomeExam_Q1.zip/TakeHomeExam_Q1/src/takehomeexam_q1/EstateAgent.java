/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package takehomeexam_q1;
//ST10261605

//Interface
 interface IEstateAgent {
    double estateAgentSales(double[] propertySales);
    double estateAgentCommission(double propertySales);
    int topEstateAgent(double[] totalSales);
}

public class EstateAgent implements IEstateAgent {
    
    @Override
    public double estateAgentSales(double[] propertySales) {
        double totalSales = 0; //acts as a counter
        for (double sale : propertySales) { //loop from sales to propertySales value
            totalSales += sale; //add sale to totalSales
        }
        return totalSales; //return totalSales
    }

    @Override
    public double estateAgentCommission(double propertySales) {
        //2% comission on sales
        return 0.02 * propertySales;
    }

    @Override
public int topEstateAgent(double[] totalSales) {
    int topAgent = 0; //acts as a counter
    double maxSales = totalSales[0]; //starts at first sale

    for (int i = 1; i < totalSales.length; i++) { //loops through the sales
        if (totalSales[i] > maxSales) { //if sales at that position is greater than starting sale amount
            maxSales = totalSales[i]; //max sale becomes that value
            topAgent = i; //top agent index
        }
    }
    return topAgent; //returns top agent
}



}


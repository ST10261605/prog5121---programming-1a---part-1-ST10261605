/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package takehomeexam_q1;
//ST10261605

import java.text.DecimalFormat;


public class TakeHomeExam_Q1 {
    
    //declaring global 2D array
    private static final double [] [] propertySales = { {800000, 1500000, 2000000}, 
                                                                          {700000, 1200000, 1600000} };
    
    //declaring global 1D array's
    private static final String [] estateAgents = {"Joe Bloggs", "Jane Doe"};
    
    public static void main(String[] args) {
        //calling various methods in the main
        printHeadings(); 
        printSales();
        
        //declaring an array that calculates the totalSales 
        double[] totalSales = calculateTotalSales(propertySales);
                
        //using methods from EstateAgent class for Joe Bloggs
        EstateAgent joeBloggsAgent = new EstateAgent(); //instantiating Joe EstateAgent class
        double joeBloggsSales = joeBloggsAgent.estateAgentSales(propertySales[0]); //Joe Bloggs sales in first row
        double joeBloggsCommission = joeBloggsAgent.estateAgentCommission(joeBloggsSales); //commision amount using commision method in EstateAgent class
         
        EstateAgent janeDoeAgent = new EstateAgent(); //instantiating Jane EstateAgent class
        double janeDoeSales = janeDoeAgent.estateAgentSales(propertySales[1]); //Jane Doe sales in second row
        double janeDoeCommission = janeDoeAgent.estateAgentCommission(janeDoeSales); //comission amount using commission method in EstateAgent class
        
        //getting the index of the top performing estate agent
        int topAgentIndex =  joeBloggsAgent.topEstateAgent(totalSales);
        String topAgentName;
        
        //if index is 1, it's Joe
        if (topAgentIndex == 1) {
             topAgentName = "Joe Bloggs";
        } else {
            //if not, it is Jane
            topAgentName = "Jane Doe";
        }
        
        //decimalFormat used to format number to 2 decimal places
        DecimalFormat formatter = new DecimalFormat("#,###.00"); 
         
        //displaying total sales, commision and top performing agent 
        System.out.println("Total Property Sales for Joe Bloggs = R" + formatter.format(joeBloggsSales));
        System.out.println("Total Property Sales for Jane Doe = R" + formatter.format(janeDoeSales) + "\n");
        System.out.println("Joe Bloggs Commission = R" + formatter.format(joeBloggsCommission));
        System.out.println("Jane Doe Comission = R" +formatter.format(janeDoeCommission) + "\n");
        System.out.println("Top performing estate agent: " + topAgentName);      
    }
    
    private static void printHeadings() {
        //prints out headings
        System.out.println("ESTATE AGENT SALES REPORT");
        System.out.println("\t\t\t" + "JAN" + "\t\t" + "FEB" + "\t\t\t" + "MARCH");
        System.out.println("------------------------------------------------------------------------------");
    }
    
      private static void printSales() {
        //looping twice to display two agents
        for (int i = 0; i < 2; i++) {
            System.out.print(estateAgents[i] + "\t"); //print out agent names
            //looping thrice to display all property sales
            for (int j = 0; j < 3; j++) {
                System.out.print("\t" + "R" + propertySales[i][j] + "\t"); //print out property sales in accordance to agent name
            }    
            System.out.println(""); //for correct formatting
        }
            System.out.println(""); //for correct formatting
}
       private static double[] calculateTotalSales(double[][] propertySales) {
           //method to calculate total sales
        double[] totalSales = new double[3];
        for (int i = 0; i < propertySales.length; i++) {
            for (int j = 0; j < propertySales.length; j++) {
                totalSales[j] += propertySales[i][j];
            }
        }
        return totalSales; //returns total sales
      } 
    } 
   

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package takehomeexam_q1;
//ST10261605

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Sami
 */
public class EstateAgentTest {
    
    public EstateAgentTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void calculateTotalSales_ReturnsTotalSales() {
        //calculates and returns total Sales of Joe Bloggs
        System.out.println("estateAgentSales");
        double[] propertySales = {800000, 1500000, 2000000};
        EstateAgent instance = new EstateAgent();
        double expResult = 4300000.00;
        double result = instance.estateAgentSales(propertySales);
        assertEquals(expResult, result, 4300000.00);
       
    }
    @Test
    public void CalculateTotalCommission_ReturnsCommission() {
        //calculates and returns commission amount of Joe Bloggs
        System.out.println("estateAgentCommission");
        double propertySales = 4300000.00;
        EstateAgent instance = new EstateAgent();
        double expResult = 86000.00;
        double result = instance.estateAgentCommission(propertySales);
        assertEquals(expResult, result, 86000.00);
 
    }
    
    @Test
    public void topAgent_ReturnsTopPosition() {
        //calculates and returns the top performing estate agent (index) - index 1 = Joe, index 2 = Jane
        System.out.println("topEstateAgent");
        double[] totalSales = {800000, 1500000, 2000000, 700000, 1200000, 1600000};
        EstateAgent instance = new EstateAgent();
        int expResult = 1;
        int result = instance.topEstateAgent(totalSales);
        assertEquals(expResult, result, 1);
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package takehomeexam_q1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Sami
 */
public class IEstateAgentTest {
    
    public IEstateAgentTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of estateAgentSales method, of class IEstateAgent.
     */
    @Test
    public void testEstateAgentSales() {
        System.out.println("estateAgentSales");
        double[] propertySales = null;
        IEstateAgent instance = new IEstateAgentImpl();
        double expResult = 0.0;
        double result = instance.estateAgentSales(propertySales);
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of estateAgentCommission method, of class IEstateAgent.
     */
    @Test
    public void testEstateAgentCommission() {
        System.out.println("estateAgentCommission");
        double propertySales = 0.0;
        IEstateAgent instance = new IEstateAgentImpl();
        double expResult = 0.0;
        double result = instance.estateAgentCommission(propertySales);
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of topEstateAgent method, of class IEstateAgent.
     */
    @Test
    public void testTopEstateAgent() {
        System.out.println("topEstateAgent");
        double[] totalSales = null;
        IEstateAgent instance = new IEstateAgentImpl();
        int expResult = 0;
        int result = instance.topEstateAgent(totalSales);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    public class IEstateAgentImpl implements IEstateAgent {

        public double estateAgentSales(double[] propertySales) {
            return 0.0;
        }

        public double estateAgentCommission(double propertySales) {
            return 0.0;
        }

        public int topEstateAgent(double[] totalSales) {
            return 0;
        }
    }
    
}
